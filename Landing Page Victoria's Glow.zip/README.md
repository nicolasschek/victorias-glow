
  # Landing Page Victoria's Glow (Copy)

  This is a code bundle for Landing Page Victoria's Glow (Copy). The original project is available at https://www.figma.com/design/6EYjAXo6AveJrQNHy9kxyq/Landing-Page-Victoria-s-Glow--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  